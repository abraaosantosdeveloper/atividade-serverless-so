# Prints a tirar (apague este arquivo depois de colocar as imagens)

1. `01-versoes.png`: `docker --version`, `sam --version`, `python --version`
2. `02-build.png`: saída do `sam build`
3. `03-invoke-1.png` e `04-invoke-2.png`: as duas execuções de `time sam local invoke -e events/pedido.json` (aparecendo REPORT, statusCode 201 e o tempo)
4. `05-start-api-sem-warm.png`: as 3 respostas do curl sem `--warm-containers`
5. `06-start-api-lazy.png`: as 3 respostas do curl com `--warm-containers LAZY`
6. `07-timeout-3s.png`: resposta 502 + log "timed out after 3 seconds"
7. `08-timeout-10s.png`: `Timeout: 10` no template + resposta 201 depois de ~5 s

## Roteiro do vídeo (até 3 min)
- 0:00–0:20: mostrar o template.yaml (rota POST /guias, Timeout) e o app.py
- 0:20–1:00: `sam build` + `sam local invoke -e events/pedido.json` duas vezes
- 1:00–2:00: `sam local start-api` + 3 curls; depois `--warm-containers LAZY` + 3 curls (mostrar invocacaoNesteAmbiente)
- 2:00–2:50: curl com `"demorar":true` dando 502/timeout; trocar Timeout para 10, `sam build`, repetir e mostrar 201
